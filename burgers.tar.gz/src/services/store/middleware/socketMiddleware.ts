import { Middleware } from "redux";
import {
  wsConnectionClosed,
  wsConnectionError,
  wsConnectionStart,
  wsConnectionSuccess,
  wsGetOrders,
} from "../orders/OrdersSlice";

export const socketMiddleware = (wsUrl: string, wsActions: any): Middleware => {
  return (store: any) => {
    let socket: WebSocket | null = null;

    return (next: any) => (action: any) => {
      const { dispatch, getState } = store;
      const { type, payload } = action;

      const { user } = getState().user;
      if (type === "orders/wsConnectionStart") {
        // socket = new WebSocket(`${wsUrl}?token=${user.token}`);
        socket = new WebSocket(`${wsUrl}`);
      }

      if (socket) {
        socket.onopen = (event) => {
          dispatch(wsConnectionSuccess);
        };

        socket.onerror = (event) => {
          dispatch(wsConnectionError(event));
        };

        socket.onmessage = (event) => {
          const { data } = event;
          const parsedData = JSON.parse(data);
          const { success, ...restParsedData } = parsedData;

          dispatch(wsGetOrders(restParsedData));
        };

        socket.onclose = (event) => {
          dispatch(wsConnectionClosed);
        };

        // if (type === wsSendMessage) {
        //   const message = { ...payload, token: user.token };
        //   socket.send(JSON.stringify(message));
        // }
      }

      next(action);
    };
  };
};
