import { OrderWs } from "./../../../../ts/interfaces/types/orders-ws";
import {
  OrdersWs,
  WebsocketStatus,
} from "../../../../ts/interfaces/types/orders-ws";
import { createReducer } from "@reduxjs/toolkit";
// import { liveTableUpdate } from "./live-table-update";
import { wsOpen, wsClose, wsMessage, wsError, wsConnecting } from "./actions";

export type OrdersWsStore = {
  status: WebsocketStatus;
  connectionError: string;
  orders: OrderWs[] | [];
  total: number | null;
  totalToday: number | null;
  loading: boolean;
};

const initialState: OrdersWsStore = {
  status: WebsocketStatus.OFFLINE,
  connectionError: "",
  orders: [],
  total: null,
  totalToday: null,
  loading: true,
};

export const ordersWsReducer = createReducer(initialState, (builder) => {
  builder
    .addCase(wsConnecting, (state) => {
      console.log("wsConnecting");
      state.status = WebsocketStatus.CONNECTING;
    })
    .addCase(wsOpen, (state) => {
      console.log("wsOpen");
      state.status = WebsocketStatus.ONLINE;
      state.connectionError = "";
    })
    .addCase(wsClose, (state) => {
      console.log("wsClose");
      state.status = WebsocketStatus.OFFLINE;
    })
    .addCase(wsError, (state, action) => {
      console.log("wsError", action);
      state.connectionError = action.payload;
    })
    .addCase(wsMessage, (state, action) => {
      console.log("wsMessage", action);
      //   state.data = liveTableUpdate(state.table, action.payload);
      state.orders = action.payload.orders;
      state.total = action.payload.total;
      state.totalToday = action.payload.totalToday;
      state.loading = false;
    });
});

/*
Если будет вопрос можно расскажать, что createSlice не выводит
экшены с type литерального типа и совсем строгую типизацию так не получить

const liveTableSlice = createSlice({
  name: "live-table",
  initialState,
  reducers: {
    wsOpen: (state) => {
      state.status = WebsocketStatus.ONLINE;
      state.connectionError = null;
    },
    wsClose: (state) => {
      state.status = WebsocketStatus.OFFLINE;
    },
    wsMessage: (state, action: PayloadAction<LiveTableActions>) => {
      state.table = liveTableUpdate(state.table, action.payload)
    },
    wsError: (state, action: PayloadAction<Event>) => {
      state.status = WebsocketStatus.ONLINE;
      state.connectionError = null;
    }
  }
})
export const liveTableReducer = liveTableSlice.reducer;
export const actions = liveTableSlice.actions
*/
