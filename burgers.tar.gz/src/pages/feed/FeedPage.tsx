import OrdersFeed from "../../components/orders-feed/OrdersFeed";

function FeedPage() {
  return <OrdersFeed />;
}

export default FeedPage;
