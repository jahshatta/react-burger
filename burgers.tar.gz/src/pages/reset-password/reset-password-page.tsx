import { ReactElement } from "react";
import ResetPasswordForm from "../../components/reset-password-form/reset-password-form";

function ResetPasswordPage(): ReactElement {
  return <ResetPasswordForm />;
}

export default ResetPasswordPage;
