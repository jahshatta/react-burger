import { ReactElement } from "react";
import ProfileForm from "../../components/profile/profile-form";

function ProfileFormPage(): ReactElement {
  return <ProfileForm />;
}

export default ProfileFormPage;
