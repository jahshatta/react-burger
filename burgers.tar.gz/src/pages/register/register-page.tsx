import { ReactElement } from "react";
import RegisterForm from "../../components/register-form/register-form";

function RegisterPage(): ReactElement {
  return <RegisterForm />;
}

export default RegisterPage;
