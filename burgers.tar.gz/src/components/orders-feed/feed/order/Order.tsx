import { NavigateFunction, useNavigate } from "react-router-dom";
import { FormattedDate } from "@ya.praktikum/react-developer-burger-ui-components";
import IngredientsList from "./ingredients-list/IngredientsList";
import styles from "./styles.module.css";

type Props = {
  data: any;
};

function Order({ data }: Props) {
  const navigate: NavigateFunction = useNavigate();

  return (
    <div
      className={`${styles.card} p-6`}
      onClick={(): void => {
        console.log("onClick", data);
        navigate(`/feed/${data.number}`, {
          state: {
            showModal: true,
            order: data,
          },
        });
      }}
    >
      <div className={styles.header}>
        <p className="text text_type_digits-default">{`#${data.number}`}</p>
        <p className="text text_type_main-default text_color_inactive">
          <FormattedDate date={new Date(data.createdAt)} />
        </p>
      </div>
      <p className="text text_type_main-medium pt-6 pb-6">{data.name}</p>
      <IngredientsList ids={data.ingredients} />
    </div>
  );
}

export default Order;
