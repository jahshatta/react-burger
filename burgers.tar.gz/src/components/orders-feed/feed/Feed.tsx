import Order from "./order/Order";
import { useAppSelector } from "../../../hooks/store";
import { OrderWs } from "../../../ts/interfaces/types/orders-ws";
import styles from "./styles.module.css";

function Feed() {
  const orders = useAppSelector((state) => state.ordersWs.orders);
  console.log("orders", orders);
  return (
    <section className={`${styles.feed} pr-2 custom-scroll`}>
      {orders.map((order: OrderWs) => (
        <Order data={order} key={order.number} />
      ))}
    </section>
  );
}

export default Feed;
