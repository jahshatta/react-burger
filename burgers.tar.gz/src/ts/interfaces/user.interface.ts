export interface IUser {
  email: string;
  name: string;
}
